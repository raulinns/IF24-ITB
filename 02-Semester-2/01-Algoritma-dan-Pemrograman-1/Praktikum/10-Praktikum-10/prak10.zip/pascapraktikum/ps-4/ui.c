#include "ui.h"
// Diperbolehkan membuat fungsi antara jika dibutuhkan!

void dealokasiList(List *l) {
    Address p_current = FIRST(*l); // Dapatkan pointer ke elemen pertama
    Address p_next;

    while (p_current != NULL) {
        p_next = NEXT(p_current); // Simpan pointer ke elemen berikutnya
        free(p_current);          // Bebaskan memori elemen saat ini
        p_current = p_next;       // Pindah ke elemen berikutnya
    }

    *l = NULL; // Setelah semua node dibebaskan, set pointer list utama ke NULL
}

void insertSorted(List *l, ElType val) {
    Address p = FIRST(*l);
    int i;
    
    while (p != NULL) {
        if (INFO(p) < val) {
            i++;
            break;
        }
    }
    insertAt(l, val, i);
}

List getUnion(List l1, List l2){
    List lResult;
    CreateList(&lResult);
    int i;

    Address p = FIRST(l1);
    while (p != NULL) {
        insertSorted(&lResult, INFO(p));
    }

    p = FIRST(l2);
    while (p != NULL) {
        insertSorted(&lResult, INFO(p));
    }

    p = FIRST(lResult);
    while (p != NULL) {
        if (INFO(p) != INFO(NEXT(p))) {
            i++;
        } else {
            int temp;
            deleteAt(&lResult, i, &temp);
        }
    }
    return l1;
}

List getIntersect(List l1, List l2){
    List lResult;
    return l1;
}

void getData(List *Union, List *Irisan) {
    List l1, l2, Union, Irisan;
    CreateList(&l1);
    CreateList(&l2);
    int N, x, temp;
    scanf("%d", &N);

    for (int i = 0; i < N; i++) {
        scanf("%d", &x);
        
        for (int j = 0; j < x; j++) {
            scanf("%d", &temp);
            insertLast(Union, temp);
            insertLast(Irisan, temp);
        }
    }
}
